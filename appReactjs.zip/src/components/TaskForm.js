import React, { Component } from 'react';
import { connect } from 'react-redux';
import moment from 'moment';
import * as actions from './../actions/index';

class TaskForm extends Component {

    constructor(props) {
        super(props);
        this.state = {
            id : '',
            name : '',
            isChecked: false,
            date: moment(),
        };
    }

    componentWillMount() {
        if(this.props.itemEditing && this.props.itemEditing.id !== null){
            this.setState({
                id : this.props.itemEditing.id,
                name : this.props.itemEditing.name,
            });
        }else{
            this.onClear();
        }
    }

    componentWillReceiveProps(nextProps) {
        if(nextProps && nextProps.itemEditing){
            this.setState({
                id : nextProps.itemEditing.id,
                name : nextProps.itemEditing.name,
            });
        }else{
            this.onClear();
        }
    }

    onHandleChange = (event) => {
        var target = event.target;
        var name = target.name;
        var value = target.type === 'checkbox' ? target.checked : target.value;
        this.setState({
            [name] : value
        });
    }

    onSave = (event) => {
        event.preventDefault();
        this.props.onSaveTask(this.state);
        this.onClear();
        this.onExitForm();
    }

    onClear = () => {
        this.setState({
            name : ''
        });
    }

    onExitForm = () => {
        this.props.onCloseForm();
    }

    onChange = (event) => {
        var target = event.target;
        var name = target.name;
        var value = target.type === 'checkbox' ? target.checked : target.value;
        this.setState({
            [name] : value
        });
    }

    handleDateTimeSelect = (date) => {
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth()+1;
        var yyyy = today.getFullYear();
        if(dd<10){
                dd='0'+dd
            } 
            if(mm<10){
                mm='0'+mm
            } 

        today = yyyy+'-'+mm+'-'+dd;
        document.getElementById("datefield").setAttribute("min", today);
    }

    render() {
        if(!this.props.isDisplayForm) return null;
        return (
            <div className="panel">
                <div className="panel-heading">
                    <h3 className="panel-title text-center">
                        { !this.state.id ? 'New task ' : 'Update task' }
                       
                    </h3>
                </div>
                <div className="panel-body">
                    <form onSubmit={this.onSave} >
                        <div className="form-group">    
                            <input
                                type="text"
                                className="form-control"
                                name="name"
                                value={this.state.name}
                                placeholder="Add new task..."
                                onChange={ this.onHandleChange }
                            />
                            
                        </div>
                        <div className="form-group">
                            <label htmlFor="description">Description</label>

                            <textarea 
                                id="description" 
                                name="description" 
                                rows="4" 
                                cols="50"
                                value= { this.state.description }
                                className="form-control"
                            >

                            </textarea>
                        </div>
                        <div className="row form-group">
                            <div className="col-lg-6">
                                <label>Due date</label>
                                <input
                                    type="date"
                                    className="form-control"
                                    name="name"
                                    id="datefield"
                                    placeholder="Add new task..."
                                    onChange={(_date) => this.handleDateTimeSelect(_date)}
                                />
                            </div>
                            <div className="col-lg-6">
                                <label>Piority :</label>
                                <select
                                    className="form-control"
                                    name="selectPriority"
                                >   
                                    <option value="">Normal</option>
                                    <option value="">Low</option>
                                    <option value="">Hight</option>
                                </select>
                            </div>
                        </div>
                        
                        <div className="text-center form-group">
                            <button type="submit" className="btn btn-success mr-5">
                                <span className="fa fa-plus"></span>
                                { !this.state.id ? 'Add' : 'Update' }
                            </button>
                            <button type="button" onClick={ this.onExitForm } className="btn btn-danger">
                                <span className="fa fa-close mr-5"></span>Close
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        isDisplayForm : state.isDisplayForm,
        itemEditing : state.itemEditing
    }
};

const mapDispatchToProps = (dispatch, props) => {
    return {
        onSaveTask : (task) => {
            dispatch(actions.saveTask(task));
        },
        onCloseForm : () => {
            dispatch(actions.closeForm());
        }
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(TaskForm);
