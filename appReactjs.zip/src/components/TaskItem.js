import React, { Component } from 'react';
import { connect } from 'react-redux';
import * as actions from './../actions/index';

class TaskItem extends Component {
    constructor() {
        super();
        this.state = { 
            isChecked: false 
        };
    }

    onDeleteItem = () => {
        this.props.onDeleteTask(this.props.task.id);
        this.props.onCloseForm();
    }

    onEditTask = (e) => {
        this.props.onOpenForm();
        this.props.onEditTask(this.props.task);
    }

    handleChange = (e) => {
		this.setState({
            isChecked: !this.state.isChecked
        })
    }

    
    render() {
        const content = this.state.isChecked 
    	    ?   <div class="wrapModal">
                    <div className="modalDialog">
                        <div className="modalContent">
                            <div className="button-items">
                                <button
                                    type="button"
                                    className="btn btn-info btn-sm mr-5"
                                    >Done
                                </button>
                                    
                                <button
                                    type="button" className="btn btn-danger btn-sm"
                                    onClick={ this.onDeleteItem }>Remove
                                </button>

                            </div>
                        </div>
                    </div>
                    
                    
                </div>
            : null;
        return (
            <tr>
                <td>
                    <input type="checkbox"  onChange={ this.handleChange }/>
                    {content}
                </td>
                
                <td>{ this.props.task.name }</td>
                <td>
                    <div className="button-items text-right">
                        <button
                            type="button"
                            className="btn btn-info btn-sm mr-5"
                            onClick={ this.onEditTask }>Detail
                        </button>
                        <button
                            type="button" className="btn btn-danger btn-sm"
                            onClick={ this.onDeleteItem }>Remove
                        </button>
                    </div>
                </td>
                
            </tr>
            
        );
    }
}

const mapStateToProps = state => {
    return {};
};

const mapDispatchToProps = (dispatch, props) => {
    return {
        onDeleteTask : (id) => {
            dispatch(actions.deleteTask(id))
        },
        onCloseForm : () => {
            dispatch(actions.closeForm());
        },
        onOpenForm : () => {
            dispatch(actions.openForm());
        },
        onEditTask : (task) => {
            dispatch(actions.editTask(task));
        },
        onOpenModal : () => {
            dispatch(actions.openModal())
        }
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(TaskItem);
