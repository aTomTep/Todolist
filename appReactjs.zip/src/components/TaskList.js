import React, { Component } from 'react';
import TaskItem from './TaskItem';
import { connect } from 'react-redux';
import * as actions from './../actions/index';

class TaskList extends Component {

    constructor(props) {
        super(props);
        this.state = {
            filterName : ''
        };
    }

    onChange = (event) => {
        var target = event.target;
        var name = target.name;
        var value = target.type === 'checkbox' ? target.checked : target.value;
        var filter = {
            name : name === 'filterName' ? value : this.state.filterName,
        };
        this.props.onFilterTable(filter);
        this.setState({
            [name] : value
        });
    }

    render() {
        var { tasks, filterTable, keyword } = this.props;
        // filter on table
        if(filterTable.name){
            tasks = tasks.filter((task) => {
                return task.name.toLowerCase().indexOf(filterTable.name.toLowerCase()) !== -1
            });
        }

        

        // search
        tasks = tasks.filter((task) => {
            return task.name.toLowerCase().indexOf(keyword.toLowerCase()) !== -1;
        });

        

        var itemTasks = tasks.map((task, index) => {
            return (
                <TaskItem
                    key={ task.id }
                    task={ task }
                    index={ index + 1 }
                />
            )
        });

        return (
            <div className="row">
                <div className="panel">
                    <div className="panel-heading">
                        <h3 className="panel-title text-center">
                            Todolist
                        </h3>
                    </div>
                </div>
                <div className="col-lg-12">
                    <div className="form-group">
                        <input
                        type="text"
                        className="form-control"
                        name="filterName"
                        placeholder="Search..."
                        onChange={ this.onChange }
                        value={ this.state.filerName }
                    />
                    </div>
                </div>
                <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <table className="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Task name</th>
                                <th>
                                    <p className="text-right">
                                        Action
                                    </p>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            { itemTasks }
                        </tbody>
                    </table>
                </div>
                
                
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        tasks : state.tasks,
        filterTable : state.filterTable,
        keyword : state.search,
        sort : state.sort
    }
};

const mapDispatchToProps = (dispatch, props) => {
    return {
        onFilterTable : (filter) => {
            dispatch(actions.filterTask(filter));
        }
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(TaskList);
